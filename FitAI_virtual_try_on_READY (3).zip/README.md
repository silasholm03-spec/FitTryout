# FitAI – AI Virtual Try-On

Dette er en komplet lokal prototype af en AI-virtual-try-on-hjemmeside.

## Sådan starter du den

Du skal have Node.js installeret.

1. Åbn Terminal i projektmappen.
2. Kør:

```bash
npm install
```

3. Lav en fil der hedder `.env` ud fra `.env.example`.
4. Sæt din Replicate API-nøgle ind:

```text
REPLICATE_API_TOKEN=din_nøgle
```

5. Start:

```bash
npm start
```

6. Åbn:

```text
http://localhost:3000
```

## Sådan virker den

- Upload et billede af dig selv.
- Upload et billede af tøjet.
- Tryk "Prøv tøjet på mig".
- Serveren sender billederne til virtual try-on-modellen.
- Resultatet bliver vist på hjemmesiden.

Replicate's JavaScript-klient kan automatisk uploade lokale `Buffer`-filer som model-input, så hjemmesiden behøver ikke en separat offentlig billedhost.

## AI-model

Projektet bruger den aktuelle version, der er pinned i `server.js`, af:

`prunaai/p-image-try-on`

Modellen tager et personbillede og et eller flere tøjbilleder og returnerer et billede.

## API-nøgle

API-nøglen ligger kun i `.env` på serveren. Del aldrig `.env` eller din nøgle med andre.

## Vigtigt om billeder

Uploadede billeder gemmes kun midlertidigt på serveren under behandlingen og slettes efter forsøget. Replicate modtager billederne som model-input, og resultatet leveres fra Replicate.

Til en offentlig hjemmeside bør du også tilføje:
- login/rate limiting
- filstørrelsesgrænser
- privatlivspolitik
- tydeligt samtykke til billedbehandling
- moderering og abuse protection
- HTTPS
- sikker hosting

## Kommerciel brug

Tjek altid den aktuelle models licens og brugsbetingelser, før FitAI bruges som en offentlig eller kommerciel tjeneste.
