require("dotenv").config();

const express = require("express");
const multer = require("multer");
const fs = require("node:fs/promises");
const path = require("node:path");
const Replicate = require("replicate");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_FILE_SIZE = 15 * 1024 * 1024;

const upload = multer({
  dest: path.join(__dirname, "uploads"),
  limits: { fileSize: MAX_FILE_SIZE },
  fileFilter: (_req, file, cb) => {
    cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype));
  }
});

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN
});

// Current pinned version of prunaai/p-image-try-on.
// The model accepts a person image and one or more garment images.
const MODEL =
  "prunaai/p-image-try-on:992f365fb343e34c43bae538d5d09e766790f011a9e4a2dea5088568c18f5e90";

app.use(express.static(__dirname));

app.post(
  "/api/try-on",
  upload.fields([
    { name: "person", maxCount: 1 },
    { name: "clothes", maxCount: 1 }
  ]),
  async (req, res) => {
    const person = req.files?.person?.[0];
    const clothes = req.files?.clothes?.[0];

    if (!person || !clothes) {
      return res.status(400).json({
        error: "Upload både et billede af dig selv og et billede af tøjet."
      });
    }

    if (!process.env.REPLICATE_API_TOKEN) {
      await cleanup([person.path, clothes.path]);
      return res.status(500).json({
        error: "AI-nøglen mangler. Tilføj REPLICATE_API_TOKEN i .env."
      });
    }

    try {
      const image = await createTryOn(person.path, clothes.path);
      res.json({ image });
    } catch (error) {
      console.error(error);
      res.status(500).json({
        error: error?.message || "AI-genereringen fejlede. Prøv igen."
      });
    } finally {
      await cleanup([person.path, clothes.path]);
    }
  }
);

async function createTryOn(personPath, clothesPath) {
  // Replicate's Node client automatically uploads Buffer inputs.
  // This avoids putting the user's photos on a separate public image host.
  const personBuffer = await fs.readFile(personPath);
  const clothesBuffer = await fs.readFile(clothesPath);

  const output = await replicate.run(MODEL, {
    input: {
      person_image: personBuffer,
      garment_images: [clothesBuffer],
      preserve_input_size: true,
      output_format: "jpg",
      output_quality: 95
    }
  });

  // p-image-try-on returns one image URL/FileOutput.
  if (typeof output === "string") return output;
  if (Array.isArray(output) && output[0]) {
    return typeof output[0].url === "function"
      ? output[0].url()
      : String(output[0]);
  }
  if (output && typeof output.url === "function") return output.url();

  throw new Error("AI-modellen returnerede ikke et billede.");
}

async function cleanup(paths) {
  await Promise.all(paths.map(p => fs.unlink(p).catch(() => {})));
}

app.listen(PORT, () => {
  console.log(`FitAI kører på http://localhost:${PORT}`);
});
